export const TEST_ANIMALS = {
    LUNICA: {
        id: 'f055cc31-fdeb-4c65-bb73-4f558f67dd2b',
        name: 'Lunica'
    },
    BOLINHAS: {
        id: 'f055cc31-fdeb-4c65-bb73-4f558f67dd1b',
        name: 'Bolinhas'
    },
    MIKA: {
        id: 'f055cc31-fdeb-4c65-bb73-4f558f67dd4b',
        name: 'Mika'
    },
    THOR: {
        id: 'f055cc31-fdeb-4c65-bb73-4f558f67dd5b',
        name: 'Thor'
    }
};