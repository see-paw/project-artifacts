export const mockFosteringSuccess = {
    id: "11111111-1111-1111-1111-111111111111",
    monthlyValue: 10,
    startDate: "2025-01-01",
    status: "Active"
};
