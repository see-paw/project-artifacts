﻿export const mockAnimalsPage1 = {
    items: [
        {
            id: "mock-animal-001",
            name: "Rex Mock",
            species: "Dog",
            size: "Medium",
            sex: "Male",
            breed: {
                id: "breed-001",
                name: "Labrador Retriever",
                description: ""
            },
            animalState: "Available",
            colour: "Brown",
            birthDate: "2020-01-01",
            age: 4,
            description: "Energetic and loyal mock dog.",
            sterilized: true,
            features: "Friendly, active",
            cost: 0,
            shelterId: "shelter-mock-01",
            images: [
            ]
        },
        {
            id: "mock-animal-002",
            name: "Luna Mock",
            species: "Dog",
            size: "Medium",
            sex: "Female",
            breed: {
                id: "breed-002",
                name: "Golden Retriever",
                description: ""
            },
            animalState: "Available",
            colour: "Golden",
            birthDate: "2021-05-12",
            age: 3,
            description: "Calm and affectionate mock dog.",
            sterilized: true,
            features: "Loves people",
            cost: 0,
            shelterId: "shelter-mock-01",
            images: [

            ]
        },
        {
            id: "mock-animal-003",
            name: "Max Mock",
            species: "Dog",
            size: "Large",
            sex: "Male",
            breed: {
                id: "breed-003",
                name: "Bulldog",
                description: ""
            },
            animalState: "Available",
            colour: "White",
            birthDate: "2019-09-20",
            age: 5,
            description: "Strong but gentle mock dog.",
            sterilized: false,
            features: "Calm, steady",
            cost: 0,
            shelterId: "shelter-mock-02",
            images: [
            ]
        },
        {
            id: "mock-animal-004",
            name: "Bella Mock",
            species: "Cat",
            size: "Small",
            sex: "Female",
            breed: {
                id: "breed-004",
                name: "Siamese",
                description: ""
            },
            animalState: "Available",
            colour: "Cream",
            birthDate: "2021-02-15",
            age: 3,
            description: "Curious and playful mock cat.",
            sterilized: true,
            features: "Very vocal",
            cost: 0,
            shelterId: "shelter-mock-02",
            images: [
            ]
        },
        {
            id: "mock-animal-005",
            name: "Charlie Mock",
            species: "Cat",
            size: "Small",
            sex: "Male",
            breed: {
                id: "breed-005",
                name: "Maine Coon",
                description: ""
            },
            animalState: "Available",
            colour: "Grey",
            birthDate: "2018-10-10",
            age: 6,
            description: "Large and fluffy mock cat.",
            sterilized: false,
            features: "Calm, affectionate",
            cost: 0,
            shelterId: "shelter-mock-03",
            images: [
            ]
        },
        {
            id: "mock-animal-006",
            name: "Molly Mock",
            species: "Dog",
            size: "Small",
            sex: "Female",
            breed: {
                id: "breed-006",
                name: "Beagle",
                description: ""
            },
            animalState: "Available",
            colour: "Tricolor",
            birthDate: "2022-03-01",
            age: 2,
            description: "Smart and highly energetic mock dog.",
            sterilized: true,
            features: "Excellent sense of smell",
            cost: 0,
            shelterId: "shelter-mock-03",
            images: [
            ]
        }
    ],

    currentPage: 1,
    pageSize: 20,
    totalPages: 1,
    totalCount: 6
};
