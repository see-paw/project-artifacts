export const TEST_ADMIN_CAA = {
    email: 'alice@test.com',
    password: 'Pa$$w0rd'
};

export const TEST_USER = {
    email: 'carlos@test.com',
    password: 'Pa$$w0rd'
};
