/**
 * Payload for creating a fostering (maps to ReqAddFosteringDto).
 */
export type AddFostering = {
  monthValue: number;
};