/**
 * Represents an animal breed
 * 
 * @interface Breed
 * @property {string} id - Unique identifier
 * @property {string} name - Breed name
 * @property {string} description - Breed description
 */
export interface Breed {
    id: string
    name: string
    description: string
}
