﻿using Application.Core;
using Application.Interfaces;
using AutoMapper;
using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Persistence;

namespace Application.Animals.Commands
{
    /// <summary>
    /// Handles the editing of an existing <see cref="Animal"/> entity.
    /// </summary>
    public class EditAnimal
    {
        /// <summary>
        /// Command containing the information necessary to edit an animal.
        /// </summary>
        public class Command : IRequest<Result<Animal>>
        {
            /// <summary>
            /// The animal entity containing all updated biological and adoption attributes.
            /// </summary>
            public required Animal Animal { get; set; }
        }
        
        /// <summary>
        /// Handles the command responsible for editing an existing <see cref="Animal"/>.
        /// </summary>
        /// <remarks>
        /// Uses Entity Framework Core to load the target animal and its related entities,  
        /// applies updates using AutoMapper, and saves the changes to the database.
        /// </remarks>
        public class Handler(AppDbContext dbContext, IMapper mapper, IUserAccessor userAccessor) : IRequestHandler<Command, Result<Animal>>
        {
            /// <summary>
            /// Updates an existing animal with new data.
            /// </summary>
            /// <param name="request">The command containing the updated animal information.</param>
            /// <param name="ct">A token to cancel the operation.</param>
            /// <returns>
            /// A <see cref="Result{T}"/> containing the updated <see cref="Animal"/> if successful,  
            /// or an error message with the corresponding status code otherwise.
            /// </returns>
            /// <exception cref="Exception">Thrown if a database operation fails unexpectedly.</exception>
            public async Task<Result<Animal>> Handle(Command request, CancellationToken ct)
            {
                var user = await userAccessor.GetUserAsync();

                var breed = await dbContext.Breeds.FirstOrDefaultAsync(b => b.Id == request.Animal.BreedId, ct);

                if (breed == null)
                {
                    return Result<Animal>.Failure(error: "Breed not found", code: 404);
                }

                request.Animal.Breed = breed;

                var animal = await dbContext.Animals // DbSet<Animal>
                    .Include(a => a.Breed) // IIncludableQueryable<Animal,Breed>
                    .Include(a => a.Shelter) // IIncludableQueryable<Animal,Shelter>
                    .Include(a => a.Images) // IIncludableQueryable<Animal,Collection<...>>
                    .FirstOrDefaultAsync(a => a.Id == request.Animal.Id, ct); // Task<Animal?>

                if (animal == null)
                    return Result<Animal>.Failure(error: "Animal not found", code: 404);

                if (animal.ShelterId != user.ShelterId)
                {
                    return Result<Animal>.Failure(error: "Animal not owned by this shelter", code: 404);
                }

                // Map updated fields from request.Animal to the existing animal entity
                mapper.Map(source: request.Animal, destination: animal);
            

            var success = await dbContext.SaveChangesAsync(ct) > 0;

                return success
                    ? Result<Animal>.Success(animal, 200)
                    : Result<Animal>.Failure("Failed to update animal", 400);
            }
        }
    }
}